import argparse, os, glob, time, csv, json, re
from datetime import datetime
import yaml

from adapters.ollama_adapter import OllamaClient
from validators.json_schema import validate_json_against_schema
from validators.grounded import grounded_validator
from validators.hangman import RuleState, hangman_step

RESULT_FIELDS = [
    "run_id","timestamp","model","task_id","type","language","pass","reason","latency_ms","output_chars"
]

def build_prompt_json(task: dict) -> str:
    tpl = task["prompt_template"]
    doc = task["inputs"]["document"]
    return tpl.replace("{{document}}", doc)

def build_prompt_grounded(task: dict) -> str:
    ctx = task["context"]
    q = task["question"]
    return f"""Lies den folgenden Kontext sorgfältig und beantworte die Frage knapp.
Wenn die Antwort NICHT im Kontext steht, sage ausdrücklich: "nicht im Text".
Kontext:
{ctx}

Frage: {q}
Antwort:"""

def build_initial_prompt_hangman(task: dict) -> str:
    return task["rules_prompt"].strip() + "\n\nErster Buchstabe:"

def load_tasks(packs_dir: str):
    tasks = []
    for path in glob.glob(os.path.join(packs_dir, "*.yaml")):
        with open(path, "r", encoding="utf-8") as f:
            t = yaml.safe_load(f)
            t["_path"] = path
            tasks.append(t)
    return tasks

def summarize(results_rows, out_md_path):
    import collections
    by_model = collections.defaultdict(list)
    for r in results_rows:
        by_model[r["model"]].append(r)

    lines = []
    lines.append(f"# BenchMate Local · Lite — Summary ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
    for model, rows in by_model.items():
        total = len(rows)
        passed = sum(1 for r in rows if r["pass"] == "1")
        lines.append(f"## {model}\n")
        lines.append(f"- Passed: **{passed}/{total}**\n")
        # Per type breakdown
        types = {}
        for r in rows:
            types.setdefault(r["type"], []).append(r)
        for t, trs in types.items():
            tp = sum(1 for r in trs if r["pass"] == "1")
            lines.append(f"  - {t}: {tp}/{len(trs)}")
        lines.append("")
    with open(out_md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True, help="Comma-separated model names (as in `ollama list`).")
    ap.add_argument("--packs", required=True, help="Directory with YAML test packs (e.g., packs/core).")
    ap.add_argument("--outdir", default="results", help="Output directory for CSV and summary.")
    ap.add_argument("--max_tokens", type=int, default=512)
    ap.add_argument("--timeout", type=int, default=120)
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    tasks = load_tasks(args.packs)
    models = [m.strip() for m in args.models.split(",") if m.strip()]

    client = OllamaClient()
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(args.outdir, f"run_{run_id}.csv")
    md_path = os.path.join(args.outdir, f"summary_{run_id}.md")

    rows = []
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=RESULT_FIELDS)
        w.writeheader()
        for task in tasks:
            ttype = task["type"]
            for model in models:
                if ttype == "json":
                    prompt = build_prompt_json(task)
                    text, latency = client.generate(model=model, prompt=prompt, temperature=0.0, max_tokens=args.max_tokens, timeout=args.timeout)
                    ok, reason = validate_json_against_schema(text, task["schema"])
                elif ttype == "grounded":
                    prompt = build_prompt_grounded(task)
                    text, latency = client.generate(model=model, prompt=prompt, temperature=0.0, max_tokens=args.max_tokens, timeout=args.timeout)
                    kw = task.get("expected_keywords") or []
                    mink = int(task.get("min_keywords", 1) or 1)
                    unknown_ok = bool(task.get("unknown_ok", False))
                    ok, reason = grounded_validator(text, task["context"], kw, mink, unknown_ok)
                elif ttype == "hangman":
                    # multi-turn; count as pass if all turns comply
                    state = RuleState()
                    prompt = build_initial_prompt_hangman(task)
                    ok_all = True
                    reason = "OK"
                    total_latency = 0
                    turns = int(task.get("turns", 5))
                    for i in range(turns):
                        text, latency = client.generate(model=model, prompt=prompt, temperature=0.0, max_tokens=8, timeout=args.timeout)
                        total_latency += latency
                        ok, r = hangman_step(text, state)
                        if not ok:
                            ok_all = False
                            reason = f"Turn {i+1}: {r} (model said: {text!r})"
                            break
                        prompt = f"Genial. Nächster Buchstabe:"  # keep the loop going with same rules
                    text = f"(hangman {turns} turns)"
                    latency = total_latency
                    ok = ok_all
                else:
                    text = "__ERROR__: Unknown task type"
                    latency = 0
                    ok = False
                    reason = "Unknown task type"

                row = {
                    "run_id": run_id,
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "model": model,
                    "task_id": task["id"],
                    "type": task["type"],
                    "language": task.get("language", ""),
                    "pass": "1" if ok else "0",
                    "reason": reason,
                    "latency_ms": str(latency),
                    "output_chars": str(len(text or "")),
                }
                rows.append(row)
                w.writerow(row)
                f.flush()
                print(f"[{model}] {task['id']} -> {'PASS' if ok else 'FAIL'} ({reason})")

    summarize(rows, md_path)
    print(f"\nWrote CSV: {csv_path}\nWrote summary: {md_path}")

if __name__ == "__main__":
    main()
